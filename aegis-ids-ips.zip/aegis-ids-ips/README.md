# Aegis IDS/IPS

**Group 16 · CSCE 4907.001 · Sponsor: WECR**
Bishika Pokharel · Rose Mapua · Brayden Fleming · Cortland Sanchez · Sugam Thapa

Aegis is an intrusion detection and prevention system (IDS/IPS). It captures network
traffic in an isolated virtual lab, streams it to a detection engine, raises alerts for
attacks, and stores them through a backend.

> **Safety:** the lab is **host-only**. Attack scripts refuse non-private IPs and need
> `--confirm-lab`. Never point them at a real network (NFR-3).

## Status (end of Sprint 2)

| Area | Status |
|---|---|
| Three-VM host-only lab (Attacker / Victim / Monitor) | Done (Sprint 1) |
| Capture, PCAP, Suricata `eve.json` | Done (Sprint 1) |
| Live feed `eve.json` → detection engine (FR-10) | Done (Sprint 2) |
| SYN-flood and SSH brute-force traffic (FR-11) | Done (Sprint 2) |
| Signature rules + anomaly rule (FR-14, FR-15) | Done / anomaly tuning |
| Sensor add and on/off control (FR-8, FR-9) | Done (Sprint 2) |
| Alert storage through the backend (FR-16) | Done (Sprint 2) |
| PCAP replay with tcpreplay (FR-12) | Script written, testing in Sprint 3 |

Exact test results are in `docs/sprint2/3_Sprint2_Test_Plan_and_Results.docx`.

## Repository layout

```
aegis-ids-ips/
├── README.md
├── docs/
│   ├── sprint1/                      Sprint 1 requirements v2.0 and draft test plan
│   └── sprint2/                      Reflection, Requirements v3.0, Design, Change, Test Plan
├── module1/                          Traffic capture and virtual test network (Bishika)
│   ├── docs/SETUP_GUIDE.md           Rebuild the lab (FR-13, NFR-6)
│   ├── live_feed/eve_feed.py         Tails eve.json and forwards events live (FR-10)
│   ├── attacker_scripts/             syn_flood.sh, ssh_bruteforce.sh, wordlist_sample.txt (FR-11)
│   └── testing/
│       ├── check_isolation.sh        TC-02 / NFR-3
│       ├── packet_loss_test.sh       TC-12 / NFR-1  -> packet_loss_results.csv
│       ├── alert_time.py             TC-13 / NFR-2
│       └── replay_pcap.sh            TC-15 / FR-12
├── samples/                          Small PCAP / eve.json samples: attack-type_date_run.pcap
└── tests/evidence/TC-nn/             Screenshots and logs, one folder per test case
```

Other modules (detection rules – Sugam, backend and alert storage – Brayden, dashboard –
Cortland, automated tests – Rose) should be added by their owners in their own folders,
for example `detection/`, `backend/`, `dashboard/`.

## Quick start (Module 1)

Full steps: [`module1/docs/SETUP_GUIDE.md`](module1/docs/SETUP_GUIDE.md). Build the three VMs first.

```bash
# Monitor VM: stream events to the detection engine
python3 module1/live_feed/eve_feed.py --mode stdout        # check events first
python3 module1/live_feed/eve_feed.py --mode tcp --host <engine_ip> --port <engine_port>

# Attacker VM: generate attacks (lab only)
./module1/attacker_scripts/syn_flood.sh <victim_ip> 80 20 --confirm-lab
./module1/attacker_scripts/ssh_bruteforce.sh <victim_ip> testuser module1/attacker_scripts/wordlist_sample.txt --confirm-lab

# Tests
./module1/testing/check_isolation.sh                       # every VM, before every demo
./module1/testing/packet_loss_test.sh <victim_ip>          # Victim runs: iperf3 -s
python3 module1/testing/alert_time.py --src <attacker_ip>  # Monitor VM, after an attack
sudo ./module1/testing/replay_pcap.sh samples/<file>.pcap <iface>
```

## Requirements to code to tests

| Requirement | Code | Test case |
|---|---|---|
| FR-10 live streaming | `live_feed/eve_feed.py` | TC-13, TC-21 |
| FR-11 attack traffic | `attacker_scripts/` | TC-14, TC-17, TC-18 |
| FR-12 PCAP replay | `testing/replay_pcap.sh` | TC-15 |
| FR-13 rebuild the lab | `docs/SETUP_GUIDE.md` | TC-10 |
| NFR-1 packet loss | `testing/packet_loss_test.sh` | TC-12 |
| NFR-2 alert time | `testing/alert_time.py` | TC-13 |
| NFR-3 isolation | `testing/check_isolation.sh` | TC-02 |

## Team workflow

- Branch per feature (`feature/live-feed`), pull request, one teammate reviews before merging to `main`.
- Commit messages: `module1: add alert_time script (TC-13)`.
- Save test evidence in `tests/evidence/TC-nn/` and name shared captures `attack-type_date_run.pcap`.
- Trello board: <paste link>

## Open items (Sprint 3)

- Set the real detection engine host/port in `eve_feed.py` (KI-08).
- Finish and test PCAP replay (FR-12, TC-15).
- Tune the anomaly rule to reduce false alarms (KI-05).
- Error handling for sensor control and the dashboard connection.
