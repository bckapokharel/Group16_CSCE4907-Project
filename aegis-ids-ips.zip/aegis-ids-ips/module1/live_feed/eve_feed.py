#!/usr/bin/env python3
"""
eve_feed.py - Aegis IDS/IPS, Module 1 (Bishika Pokharel)

Tails Suricata's eve.json on the Monitor VM and forwards each event to the
detection engine AS IT IS WRITTEN, so the engine no longer has to wait for a
PCAP file to be saved and opened by hand. Implements FR-10 (stream events
live) and feeds the detection rules (FR-14, FR-15) and the 5-second alert
target (NFR-2).

Sprint 2 hardening (found while preparing TC-13 / TC-21):
  * keeps ONE persistent TCP connection (old version reconnected per event)
  * reconnects automatically and retries the event that failed (no silent loss)
  * follows eve.json if Suricata rotates or truncates it
  * warns on stderr if no events arrive for --stale-after seconds, so a dead
    feed is noticed instead of looking like "no attacks"

Usage:
    python3 eve_feed.py --mode stdout                       # sanity check / demo
    python3 eve_feed.py --mode tcp --host 192.168.56.20 --port 5140
    python3 eve_feed.py --mode http --url http://192.168.56.20:8080/ingest
    python3 eve_feed.py --mode stdout --event-types alert --from-start   # replay a file
"""

import argparse
import json
import os
import socket
import sys
import time
import urllib.request

# ---- Defaults the team can fill in so `python3 eve_feed.py` just works ----
DEFAULT_EVE_PATH = "/var/log/suricata/eve.json"
DETECTION_HOST = "192.168.56.20"                    # [UPDATE] detection engine IP
DETECTION_PORT = 5140                               # [UPDATE] detection engine port
DETECTION_URL = "http://192.168.56.20:8080/ingest"  # [UPDATE] HTTP ingest endpoint
RECONNECT_DELAY_SEC = 2
POLL_INTERVAL_SEC = 0.25


def log(msg):
    print(f"[eve_feed] {msg}", file=sys.stderr, flush=True)


def tail_lines(path, from_start=False):
    """Yield new lines appended to `path` (like `tail -F`).

    Yields None when idle so the caller can run its stale-feed check.
    Re-opens the file if it is rotated (inode changes) or truncated.
    """
    f = None
    inode = None
    while True:
        try:
            if f is None:
                f = open(path, "r")
                inode = os.fstat(f.fileno()).st_ino
                if not from_start:
                    f.seek(0, 2)          # only forward NEW events
                from_start = False
            line = f.readline()
            if line:
                yield line
                continue
            st = os.stat(path)            # idle: check for rotation / truncation
            if st.st_ino != inode or st.st_size < f.tell():
                log("eve.json rotated or truncated; re-opening")
                f.close()
                f = None
                from_start = True         # read the new file from its top
                continue
        except FileNotFoundError:
            if f:
                f.close()
                f = None
            from_start = True
        time.sleep(POLL_INTERVAL_SEC)
        yield None


class TcpSender:
    """One persistent connection; reconnects and retries the failed line."""

    def __init__(self, host, port):
        self.host, self.port, self.sock = host, port, None

    def send(self, line):
        data = line.encode("utf-8")
        while True:
            try:
                if self.sock is None:
                    self.sock = socket.create_connection((self.host, self.port), timeout=3)
                    log(f"connected to {self.host}:{self.port}")
                self.sock.sendall(data)
                return
            except OSError as e:
                log(f"TCP send failed ({e}); retrying in {RECONNECT_DELAY_SEC}s")
                if self.sock:
                    self.sock.close()
                self.sock = None
                time.sleep(RECONNECT_DELAY_SEC)


def send_http(url, event):
    data = json.dumps(event).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        urllib.request.urlopen(req, timeout=3)
        return True
    except Exception as e:
        log(f"HTTP post failed: {e}")
        return False


def main():
    ap = argparse.ArgumentParser(description="Tail Suricata eve.json and forward events live.")
    ap.add_argument("--eve", default=DEFAULT_EVE_PATH, help="path to eve.json on the Monitor VM")
    ap.add_argument("--mode", choices=["stdout", "tcp", "http"], default="stdout")
    ap.add_argument("--host", default=DETECTION_HOST, help="detection engine host (tcp mode)")
    ap.add_argument("--port", type=int, default=DETECTION_PORT, help="detection engine port (tcp mode)")
    ap.add_argument("--url", default=DETECTION_URL, help="detection engine ingest URL (http mode)")
    ap.add_argument("--event-types", default="", help="comma list to filter, e.g. alert,flow (default: all)")
    ap.add_argument("--from-start", action="store_true", help="read the existing file from the top")
    ap.add_argument("--stale-after", type=int, default=60,
                    help="warn if no events for this many seconds (0 = never)")
    args = ap.parse_args()

    wanted = {t.strip() for t in args.event_types.split(",") if t.strip()}
    tcp = TcpSender(args.host, args.port) if args.mode == "tcp" else None

    log(f"tailing {args.eve} -> mode={args.mode}")
    sent = bad = 0
    last_event = time.time()
    warned = False

    for raw in tail_lines(args.eve, args.from_start):
        if raw is None:  # idle tick
            if args.stale_after and not warned and time.time() - last_event > args.stale_after:
                log(f"WARNING: no events for {args.stale_after}s - is Suricata running / capture on?")
                warned = True
            continue
        last_event, warned = time.time(), False
        raw = raw.strip()
        if not raw:
            continue
        try:
            event = json.loads(raw)
        except json.JSONDecodeError:
            bad += 1
            continue
        if wanted and event.get("event_type") not in wanted:
            continue

        if args.mode == "stdout":
            print(raw, flush=True)
        elif args.mode == "tcp":
            tcp.send(raw + "\n")
        else:
            send_http(args.url, event)

        sent += 1
        if sent % 100 == 0:
            log(f"forwarded {sent} events ({bad} bad lines skipped)")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("stopped")
