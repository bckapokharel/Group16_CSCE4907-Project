#!/usr/bin/env python3
"""
alert_time.py - Aegis IDS/IPS, Module 1
Measures alert time for NFR-2 / TC-13: seconds from the FIRST attack packet
to the FIRST alert in eve.json.

Run on the Monitor VM after (or during) an attack:

    python3 alert_time.py --eve /var/log/suricata/eve.json --src 192.168.56.10

First-attack-packet time defaults to the earliest eve.json event from --src.
For a stricter number, run `date +%s.%N` on the Attacker right before the
attack and pass it with --attack-start (all VMs share the host clock).

--signature "SYN"  only counts alerts whose signature contains that text.
Exit code: 0 = within --limit seconds (default 5), 1 = too slow, 2 = no alert.
"""
import argparse
import json
import sys
from datetime import datetime


def parse_ts(s):
    # Suricata: 2026-11-05T14:03:22.123456-0600
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%f%z").timestamp()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--eve", default="/var/log/suricata/eve.json")
    ap.add_argument("--src", required=True, help="Attacker IP")
    ap.add_argument("--signature", default="", help="substring of alert signature to match")
    ap.add_argument("--attack-start", type=float, help="epoch seconds when the attack began")
    ap.add_argument("--limit", type=float, default=5.0)
    a = ap.parse_args()

    first_seen = first_alert = alert_sig = None
    with open(a.eve) as f:
        for line in f:
            try:
                e = json.loads(line)
                t = parse_ts(e["timestamp"])
            except (ValueError, KeyError):
                continue
            if e.get("src_ip") != a.src:
                continue
            if first_seen is None or t < first_seen:
                first_seen = t
            if e.get("event_type") == "alert":
                sig = e.get("alert", {}).get("signature", "")
                if a.signature.lower() in sig.lower() and (first_alert is None or t < first_alert):
                    first_alert, alert_sig = t, sig

    if first_alert is None:
        print(f"No alert from {a.src} found in {a.eve}")
        sys.exit(2)

    start = a.attack_start if a.attack_start is not None else first_seen
    delta = first_alert - start
    print(f"Attacker            : {a.src}")
    print(f"First attack packet : {datetime.fromtimestamp(start).isoformat()}"
          f"{' (given)' if a.attack_start is not None else ' (earliest eve.json event)'}")
    print(f"First alert         : {datetime.fromtimestamp(first_alert).isoformat()}  [{alert_sig}]")
    print(f"Alert time          : {delta:.3f} s (limit {a.limit} s) -> "
          f"{'PASS' if delta <= a.limit else 'FAIL'}")
    sys.exit(0 if delta <= a.limit else 1)


if __name__ == "__main__":
    main()
