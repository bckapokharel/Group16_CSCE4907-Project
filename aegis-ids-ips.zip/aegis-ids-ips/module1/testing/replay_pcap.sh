#!/usr/bin/env bash
#
# replay_pcap.sh - Aegis IDS/IPS, Module 1 (FR-12, TC-15)
# Replays a saved PCAP with tcpreplay so a test can be repeated exactly.
#
# Usage (on the Monitor VM, lab interface only):
#   sudo ./replay_pcap.sh <pcap_file> <interface> [mbps=10]
# Example:
#   sudo ./replay_pcap.sh ../../samples/portscan_2026-11-03_run1.pcap eth1 10
#
# Safety (NFR-3): refuses to replay on an interface that carries the default
# route, because that could be a path out of the host-only lab.
# Afterwards compare eve.json with the live-scan run (TC-15: same events).

set -euo pipefail

PCAP="${1:-}"; IFACE="${2:-}"; MBPS="${3:-10}"
if [ -z "$PCAP" ] || [ -z "$IFACE" ]; then
  echo "Usage: sudo $0 <pcap_file> <interface> [mbps=10]"; exit 1
fi
[ -f "$PCAP" ] || { echo "PCAP not found: $PCAP"; exit 1; }
command -v tcpreplay >/dev/null || { echo "tcpreplay not found: sudo apt install tcpreplay"; exit 1; }
ip link show "$IFACE" >/dev/null 2>&1 || { echo "No such interface: $IFACE"; exit 1; }

if ip route show default 2>/dev/null | grep -q "dev $IFACE"; then
  echo "ERROR: $IFACE carries the default route (could reach outside the lab). Refusing."
  exit 1
fi

echo "=== Replaying $PCAP on $IFACE at ${MBPS} Mbps ==="
echo "Start: $(date +%s.%N)"
tcpreplay --intf1="$IFACE" --mbps="$MBPS" "$PCAP"
echo "End:   $(date +%s.%N)"
echo "Now check eve.json for the same events as the live run (TC-15)."
