#!/usr/bin/env bash
#
# check_isolation.sh - Aegis IDS/IPS, Module 1 (TC-02, NFR-3)
# Run on EACH VM before every demo/test. PASS = external ping fails.
# Also confirm in VirtualBox that every adapter is "Host-only Adapter"
# (that cannot be seen from inside the VM).
#
# Usage: ./check_isolation.sh | tee ../../tests/evidence/TC-02/$(hostname)_isolation.txt

echo "=== $(hostname) @ $(date) ==="
echo "--- interfaces ---"; ip -br addr
echo "--- default route (should be empty) ---"
ROUTE=$(ip route show default); echo "${ROUTE:-<none>}"
echo "--- ping 8.8.8.8 (should FAIL) ---"
if ping -c 2 -W 2 8.8.8.8 >/dev/null 2>&1; then
  echo "RESULT: FAIL - this VM can reach the internet. Remove the bridged/NAT adapter!"
  exit 1
fi
[ -n "$ROUTE" ] && echo "NOTE: a default route exists but the ping failed; double-check adapters."
echo "RESULT: PASS - external ping blocked"
